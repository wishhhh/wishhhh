#include "GlobalVariables.hpp"

const char* Game_Weapons[34] =
{
	("deagle"), ("elite"), ("fiveseven"), ("glock"), ("hkp2000"), ("p250"), ("usp_silencer"), ("cz75a"), ("revolver"), ("tec9"),
	("ak47"), ("aug"), ("famas"), ("galilar"), ("m249"), ("m4a1"), ("m4a1_silencer"), ("mac10"), ("p90"), ("ump45"), ("xm1014"), ("bizon"),
	("mag7"), ("negev"), ("sawedoff"), ("mp7"), ("mp5sd"), ("mp9"), ("nova"), ("sg553"), ("g3sg1"), ("scar20"), ("awp"), ("ssg08")
};

const char* Game_Pistols[11] =
{
	("none"), ("deagle"), ("elite"), ("fiveseven"), ("glock"), ("hkp2000"), ("p250"), ("usp_silencer"), ("cz75a"), ("revolver"), ("tec9")
};

const char* Game_Rifles[8] =
{
	("none"), ("ak47"), ("aug"), ("famas"), ("galilar"), ("m4a1"), ("m4a1_silencer"), ("sg556")
};

const char* Game_PP[8] =
{
	("none"), ("mac10"), ("p90"), ("ump45"), ("bizon"), ("mp7"), ("mp5sd"), ("mp9")
};

const char* Game_Snipers[5] =
{
	("none"), ("g3sg1"), ("scar20"), ("awp"), ("ssg08")
};

const char* Game_Other[7] =
{
	("none"), ("xm1014"), ("mag7"), ("negev"), ("sawedoff"), ("nova"), ("m249")
};
