#pragma once

extern const char* Game_Weapons[34];
extern const char* Game_Rifles[8];
extern const char* Game_Pistols[11];
extern const char* Game_PP[8];
extern const char* Game_Snipers[5];
extern const char* Game_Other[7];
