#pragma once
class Xor
{
public:
	char* EncryptDecrypt(const char* value, const char* key, int length);
};

